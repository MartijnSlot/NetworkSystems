package client;

public enum TransmissionResult {
    Success,
    DestinationUnreachable,
    Failure
}
